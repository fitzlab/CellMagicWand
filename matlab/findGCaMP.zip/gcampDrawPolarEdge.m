function [img, polarEdge, polarTif, edgeValues] = gcampDrawPolarEdge(tif, cx, cy, polarAngles, cellDiameterMin, cellDiameterMax)

    polarDistMin = round(cellDiameterMin/2) - 1;
    polarDist = round(cellDiameterMax/2) + 5;
    
    % set up variables
    edgeFilter =  [
        -1    -1    -1    -1    -1    -1    -1
        -1    -1    -1    -1    -1    -1    -1
         0     0     0     0     0     0     0
         1     1     1     1     1     1     1
         1     1     1     1     1     1     1];
    
    polarTif = double(imgpolarcoord(tif, cx, cy, polarAngles, polarDist-1)); 
    polarTif = polarTif(polarDistMin:end,:);
    
    % Since dynamic programming doesn't constrain its edges well, we run
    % edge detection on a double-image (0:360) and take 360 degrees from
    % the middle of the range.
    polarTif = [polarTif polarTif];
    polarTif = conv2(polarTif, edgeFilter, 'same');
    
    % draw the polar edge
    polarEdge = gcampPolarEdge(polarTif);
    polarEdge = polarEdge(:,polarAngles/2:polarAngles*3/2); 
    polarTif = polarTif(:,polarAngles/2:polarAngles*3/2);
    
    % transform back to XY coordinates
    [radius degrees] = size(polarEdge);
    img = zeros(polarDist*2, polarDist*2);
    imgCenterX = polarDist;
    imgCenterY = polarDist;
    degIncrement = 360/polarAngles;
    
    pixelsList = [];
    p = 1;
    for deg=1:degIncrement:360
        polarEdgePos = max(1,round(deg/degIncrement));
        [val r]=max(polarEdge(:,polarEdgePos));
        edgeValues(p) = polarTif(r,polarEdgePos);
        
        %find pixel nearest to that point
        r=r+polarDistMin-1;
        x = round(imgCenterX+r*cosd(deg));
        y = round(imgCenterY+r*sind(deg));
        img(x,y) = 1;
        
        % record the edge value for each marked pixel
        pixelsList(p,:) = [x y];
        p=p+1;
    end
    img = imrotate(img,180); 
    
    [vals,positions] = unique(pixelsList,'rows');
    edgeValues = edgeValues(positions);
end