
height=512;
width=512;
imagesc(intensityCorrectionMask);