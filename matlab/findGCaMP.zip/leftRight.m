subplot(311); plot(leftCell(2:end));
subplot(312); plot(contestedZone(2:end));
subplot(313); plot(rightCell(2:end));
